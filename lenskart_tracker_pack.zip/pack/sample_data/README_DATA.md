# Sample data pack: Lenskart Leadership Project Tracker

All people, numbers and events are **fictional** and only plausible. "Today" is frozen at **Sat 14 Nov 2026** (`AS_OF_DATE`). The current week is 9 Nov.

## What's inside
- **8 functions × 5 projects = 40 projects**, 32 people (one has left the company), 6 weeks of history (5 Oct to 9 Nov), 103 milestones, and a dependency graph.
- **8 raw weekly updates in 8 formats** (`weekly_updates/`): email, CSV tracker, Jira JSON, Slack thread, Markdown RAG table, slide export, formal memo, voice-note transcript.
- **3 live-demo inputs** (`demo_inputs/`), one per trigger: manual paste, webhook and inbox drop.
- **Golden answers:** `expected_scores.json` (every project's score, signals and top 3, at baseline and after each demo step) and `weekly_updates/expected_extractions.json` (parser ground truth).

## Planted stories (the answer key)
| Rank | Project | Why it surfaces | What it tests |
|---|---|---|---|
| #1 · 81.7 | **TP-01** Checkout & payments re-platform | Reported **GREEN** for 6 weeks, but 3 milestones are overdue, % complete is stuck at 62, there's been no update for 12 days, and go-live is in 6 days. It was also dropped from the Jira export. It blocks MB-01 and CX-04 | Watermelon detection; "went silent" |
| #2 · 79.0 | **SC-02** Bhiwadi lens lab Phase 2 | 41-day slip after a customs hold, commissioning overdue, confidence 4→2, 87% of budget spent at 66% complete. It blocks RE-01, CX-02 and MB-01 | Slip + dependency fan-out; under-reported (Amber, not Red) |
| #3 · 68.9 | **PC-01** Optometrist hiring (212/450) | Run-rate is half what's needed, 2 milestones are missed, confidence is 2. It blocks RE-01 and CX-01 | A people risk becomes a business risk |
| #4 · 56.8 | CX-03 NPS recovery | Real slip, but P1 | Watch list |
| #5 · 50.1 | PC-04 HQ floor move | **Blocked**, but P2 with low impact | Blocked ≠ top priority |
| #6 · 48.4 | IN-02 Dubai warehouse | Owner left 20 Oct, no update in 23 days, missing from the slides | Ownership gap |
| — | **MB-03** Brand film | Owner says **RED**, but every milestone is on time. Score 0 | `REPORTED_RED_DATA_OK` |
| — | RE-01 / MB-01 | Own data is green; they inherit `upstream_risk` from SC-02, TP-01 and PC-01 | Shown as "Impacts" |
| — | RE-04, SC-05, MB-05, FS-01, PC-03 | Done | Excluded |

## Live demo sequence
| Step | Trigger | Input | Top 3 after |
|---|---|---|---|
| Baseline | open the app | `seed.json` | TP-01, SC-02, PC-01 |
| A | paste into Ingest | `A_cx_escalation_email.txt`: fleet partner terminates, CX-01 Blocked | TP-01, SC-02, **CX-01** |
| B | webhook (curl) | `B_tp01_webhook_payload.json`: UAT and PCI done, TP-01 recovers to 32.9 | SC-02, CX-01, **PC-01** |
| C | drop in `inbox/` | `C_supply_chain_inbox_drop.csv`: third shift approved, SC-02 drops to 56.0 | CX-01, PC-01, **CX-03** |

The scheduled sweep runs every 60 seconds throughout and logs each run, whether or not the scores changed.

## Regenerating
`gen/generate.py` holds the project definitions and the reference risk engine. `gen/build_pack.py` writes every file and recomputes the golden scores (`cd gen && python3 build_pack.py`).
