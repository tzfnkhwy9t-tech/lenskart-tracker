# Customer Experience & Omnichannel — Weekly RAG
**Week of:** 9–13 Nov 2026  **Owner:** Imran Sheikh  **Distribution:** CEO Office, COO

| # | Initiative | RAG | % | Target date | Conf | Commentary |
|---|-----------|-----|---|-------------|------|------------|
| CX-01 | Home eye-test expansion (25→40 cities) | 🟢 G | 48% | 31 Jan 2027 | 4 | 29 cities live. Fleet partner contract renewal (due 1 Nov) is still being negotiated, and the partner is asking for a 22% rate increase. Optometrist supply for vans depends on PC-01. |
| CX-02 | 48-hour delivery promise → 300 cities | 🟠 A | 60% | 10 Jan 2027 | 3 | 86% hit rate in eligible cities. Expansion past 240 cities is paused until Bhiwadi Ph-2 adds capacity. |
| CX-03 | Store NPS recovery / wait times | 🟠 A | 35% | 28 Feb 2027 | 2 | NPS is 64 (target 72). The queue app pilot in 50 stores missed its 31 Oct date because of a POS integration bug. Weekend eye-test waits average 38 min. |
| CX-04 | Gold auto-renewal | 🟢 G | 40% | 15 Jan 2027 | 4 | Journey designed. Build depends on UPI Autopay from the payments re-platform. |
| CX-05 | WhatsApp support bot | 🟢 G | 72% | 15 Dec 2026 | 4 | 31% ticket deflection. Returns self-serve is in UAT. |

**Asks:** None this week.
