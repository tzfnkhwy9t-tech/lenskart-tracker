#!/usr/bin/env bash
# Demo step B: fire the webhook while the leadership view is open in a browser.
BASE=${BASE:-http://localhost:8000}
curl -s -X POST "$BASE/api/webhooks/update" \
  -H "Content-Type: application/json" \
  -H "X-Webhook-Token: ${WEBHOOK_TOKEN:-demo-token}" \
  --data @"$(dirname "$0")/B_tp01_webhook_payload.json" | python3 -m json.tool

# Demo step C: drop the CSV into the watched inbox folder (the watcher picks it up within ~10s)
# cp "$(dirname "$0")/C_supply_chain_inbox_drop.csv" ./inbox/

# Trigger the scheduled risk sweep immediately (instead of waiting for the next tick)
# curl -s -X POST "$BASE/api/automation/sweep/run-now" | python3 -m json.tool
