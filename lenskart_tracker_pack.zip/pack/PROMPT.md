# Claude Code prompt: Lenskart Leadership Project Tracker

> Paste everything below the line into Claude Code, run from a folder that contains `sample_data/` from this pack.

---

## 1. Role and goal

You are a senior full-stack engineer working with a program manager. Build a **working, running** project-tracking web app for Lenskart's CEO Office, and prove it runs end to end before you say you're done.

**The problem:** Leadership gets weekly updates from 8 functions in 8 formats (email, Excel/CSV, Jira JSON, Slack thread, Markdown RAG table, slide export, formal memo, voice-note transcript). Nobody can see what is actually slipping. Owners also self-report status optimistically, so a project can be reported "Green" and still be weeks late.

**What the app must do:**
1. Normalise all eight formats into one tracker with statuses, owners, dates, milestones and history.
2. Compute risk from the data itself (slip, overdue milestones, stalled progress, stale updates, dependencies and so on), independent of the self-reported RAG.
3. Give leadership a view that surfaces the **3 things that need attention this week**, each with the reasons and the decision needed.
4. Run at least one step automatically, without a human driving it, and visibly while someone watches.

## 2. Definition of done (non-negotiable)

You are done only when **all** of these are true, and you have verified each one yourself:

- [ ] `./run.sh` (or `make run`) starts the app with one command, from a clean clone, and prints `Open http://localhost:8000`.
- [ ] Opening `http://localhost:8000` shows the Leadership view with **TP-01, SC-02, PC-01** as the top 3 (in that order), computed from `sample_data/seed.json`. Nothing is hard-coded.
- [ ] **Something goes in, something comes back:** pasting `sample_data/demo_inputs/A_cx_escalation_email.txt` into the Ingest page shows the parsed preview, and on Apply the top 3 becomes **TP-01, SC-02, CX-01**.
- [ ] **Something fires on its own:** the scheduled Risk Sweep runs every 60 seconds in demo mode and writes a visible run log entry with timestamp, duration, items rescored and the top-3 diff. The Leadership view updates itself through polling, with no refresh needed.
- [ ] `POST /api/webhooks/update` with `demo_inputs/B_tp01_webhook_payload.json` changes the top 3 to **SC-02, CX-01, PC-01**, and the browser shows a toast within 5 seconds.
- [ ] Dropping `demo_inputs/C_supply_chain_inbox_drop.csv` into `./inbox/` is picked up automatically within about 10 seconds. The top 3 becomes **CX-01, PC-01, CX-03**.
- [ ] `pytest` passes, including the golden test against `sample_data/expected_scores.json` (±1.0 point per project, exact top-3 order) for the baseline and after each demo step A, B and C.
- [ ] `./reset.sh` (or `POST /api/admin/reset`) restores the seed state, so the demo can be repeated.
- [ ] You have actually started the server and hit every endpoint with `curl`, including the full A→B→C sequence, and pasted the output into `DEMO_LOG.md`. Code that you haven't run doesn't count.

## 3. Tech constraints

- **Python 3.11+, FastAPI, Uvicorn, SQLite (stdlib `sqlite3` or SQLModel), Jinja2 templates, vanilla JS + a small CSS file.** No React or Node build step. HTMX is allowed only if it's vendored locally.
- Scheduling: **APScheduler** (BackgroundScheduler). Folder watching: a simple polling thread every 5 seconds is fine. Don't use `watchdog` unless it's already installed.
- **No external network required to run.** Every feature must work offline with the deterministic parser.
- **Optional LLM agent:** if `ANTHROPIC_API_KEY` is set, the Ingest step may call Claude (`ANTHROPIC_MODEL` env var, with a sensible current default) to extract structured updates from free text. The deterministic parser stays the fallback and is what the tests use. Show which parser ran ("rule-based" or "Claude") on the preview.
- Config through `.env`, with defaults: `AS_OF_DATE=2026-11-14` (freeze "today" so the demo is deterministic), `DEMO_MODE=true`, `SWEEP_INTERVAL_SECONDS=60`, `WEBHOOK_TOKEN=demo-token`, `INBOX_DIR=./inbox`, `PORT=8000`.
- Keep it plain and working. Rough UI is fine. Correctness, clarity and actually running matter more than polish.

## 4. Data provided (in `sample_data/`)

| File | What it is |
|---|---|
| `seed.json` | **Load this.** `meta`, `functions` (8), `people` (32, one inactive), `projects` (40, five per function) with milestones and 6 weeks of `weekly_history` |
| `projects.json`, `people.json`, `functions.json` | Same content split out |
| `*_flat.csv` | Flat views, for eyeballing only |
| `weekly_updates/01..08_*` | This week's raw updates, one per function, each in a different format. Already reflected in `seed.json`. Use them for the Sources page and parser tests |
| `weekly_updates/expected_extractions.json` | Ground truth for what each raw update should parse into |
| `demo_inputs/A_*.txt`, `B_*.json`, `C_*.csv` | The three live-demo inputs (manual paste, webhook, inbox drop) |
| `demo_inputs/curl_examples.sh` | Ready-made curl commands |
| `expected_scores.json` | Golden risk scores, signals and top 3 for the baseline and after A, B and C |

Key fields per project: `id` (e.g. `SC-02`), `name`, `function_code`, `aliases[]`, `priority` (P0/P1/P2), `owner_id`, `exec_sponsor_id`, `status` (Not Started, On Track, At Risk, Off Track, Blocked, Done), `reported_rag`, `start_date`, `baseline_due`, `forecast_due`, `pct_complete`, `budget_inr_cr`, `spent_inr_cr`, `confidence` (1–5), `last_update_date`, `dependencies[]` (ids this project depends on), `kpi{}`, `milestones[] {name, due, done_date}`, `weekly_history[] {week_of, reported_rag, reported_status, pct_complete, forecast_due, confidence, note, source}`.

## 5. Data model (SQLite)

`functions`, `people`, `projects`, `milestones`, `dependencies(project_id, depends_on_id)`, `status_updates` (one row per project per week; the history), `ingestions` (raw text, format detected, parser used, parsed JSON, applied_at, source channel = `manual|webhook|inbox|seed`), `risk_snapshots` (run_id, project_id, score, computed_rag, signals JSON, flags JSON), `automation_runs` (id, job = `risk_sweep|webhook|inbox`, started_at, finished_at, duration_ms, status, items_rescored, top3_before, top3_after, message).

When an update is applied: update the project's current fields, mark milestones done if mentioned, **upsert** the `status_updates` row for the current week (`week_of` = Monday of `AS_OF_DATE`), set `last_update_date` = the update's date, then **immediately rescore** and log an `automation_runs` row.

## 6. Risk engine (implement exactly, because the golden test depends on it)

Use `AS_OF_DATE` for "today". Skip projects with status `Done` (score 0). For each other project, sum the signal points:

| Signal key | Rule | Points |
|---|---|---|
| `schedule_slip` | `slip = forecast_due − baseline_due` (days) > 0 | `min(30, slip × 0.75)` |
| `overdue_milestones` | milestones with no `done_date` and `due < today` | `min(24, 8 × count)` |
| `progress_gap` | status ≠ Not Started and today > start: `expected = min(100, (today−start)/(baseline_due−start) × 100)`; `gap = expected − pct_complete`; if gap > 10 | `min(15, (gap − 10) × 0.5)` |
| `stalled_progress` | last 3 `weekly_history` entries have the same `pct_complete`, pct < 100, status ≠ Not Started | 10 |
| `stale_update` | days since `last_update_date` > 21 → 15; else > 10 → 10 | 10 / 15 |
| `confidence_drop` | `max(confidence over history) − current confidence ≥ 2` | 8 |
| `low_confidence` | current confidence ≤ 2 | 5 |
| `budget_burn` | budget > 0 and `spent/budget − pct/100 > 0.15` | 8 |
| `no_active_owner` | owner missing or `people.active = false` | 12 |
| `implausible_forecast` | `0 ≤ (forecast_due − today) ≤ 14` and pct < 85 | 8 |
| `blocked` | status = Blocked | 15 |
| `downstream_impact` | count of non-Done projects that depend on this one | `min(12, 4 × count)` |

**Second pass**, after every project's pass-1 raw sum is known:
- `upstream_risk` **+10** if any dependency is not Done and has `min(100, dep_raw_pass1 × weight(dep))` ≥ 60.
- `status_mismatch` **+10** and flag **`WATERMELON`** ("green outside, red inside") if `reported_rag = Green` and the raw sum (including upstream) ≥ 40.

`score = round(min(100, raw × weight), 1)`, where weight is P0 = 1.0, P1 = 0.8, P2 = 0.55.
`computed_rag`: ≥ 60 Red, 35–59.9 Amber, < 35 Green.
Flag **`REPORTED_RED_DATA_OK`** if `reported_rag = Red` and score < 20 (an owner being overly cautious).
**Ranking:** score desc, then priority (P0 first), then slip days desc. The top 3 is the first three non-Done projects.

Every signal must carry a human-readable `why` string (for example "Forecast 2027-01-10 is 41 days past baseline 2026-11-30"). The UI shows these. Put the engine in its own pure module (`risk.py`) with no DB access, so it is trivially testable.

## 7. Screens

Simple top nav: **Leadership · All Projects · Ingest · Automation · Sources**. Put a header badge on every page: `As of 14 Nov 2026 · Next risk sweep in 0:42 · Last run #17 ✓ 12:03:05`.

**7.1 Leadership view (`/`)**, the page the CEO opens
- Headline strip: count of projects by *computed* RAG, the number of WATERMELON items, and the number of items with no update in more than 10 days.
- **"3 things that need your attention this week"**: three large cards. Each card shows: rank, id and name, function, owner, priority, score with a small trend sparkline (score per sweep run), reported RAG vs computed RAG side by side (highlight mismatches), the top 3 `why` reasons, **"Impacts:"** (downstream projects, e.g. SC-02 → RE-01, CX-02, MB-01), and a **"Decision needed"** line. Take that line from the latest note when the note contains an ask or decision ("need decision", "ask for leadership", "call on"). Otherwise generate a template line from the top signal, e.g. "Confirm a recovery plan and new date with <owner>".
- Below the cards: a **"Watch list"** with ranks 4–8, as compact rows.
- **"Reported vs reality"** panel: list WATERMELON items and REPORTED_RED_DATA_OK items (e.g. MB-03), so leadership can see where self-reporting can't be trusted in either direction.
- **"Went silent"**: projects with stale updates and the source that omitted them (TP-01 is missing from the Jira export; IN-02 is missing from the International slides because its owner left).
- Auto-refresh: poll `GET /api/leadership` every 5 seconds. When the top 3 changes, animate the card change and show a toast like "Risk sweep #18: CX-01 entered top 3 (+58.0), PC-01 dropped to #4".

**7.2 All Projects (`/projects`)**: a filterable, sortable table (function, priority, owner, reported RAG, computed RAG, score, % complete, forecast vs baseline, last update, flags). Clicking a row opens the detail page.

**7.3 Project detail (`/projects/{id}`)**: header fields, a score breakdown table (signal, points, why), the milestones list with Done/Late/Overdue/Open chips, the 6-week history table (reported RAG, %, forecast, confidence, note, source link), dependencies both ways, the KPI target vs actual, and an "Edit status" form (status, RAG, %, forecast, confidence, note). Saving the form counts as an ingestion with channel `manual`.

**7.4 Ingest (`/ingest`)**: a textarea plus file upload, and a function dropdown with "Auto-detect" as default. Click **Parse**, which shows a preview table of extracted updates (project, field, old → new) with the parser used and any warnings (e.g. "Saw 'IN-02' nowhere"). Click **Apply**, which applies the updates, rescores, and redirects to Leadership with the toast.

**7.5 Automation (`/automation`)**: next-run countdown, a **Run sweep now** button, a pause/resume toggle, the table of `automation_runs` (newest first, auto-refreshing), the webhook URL, a copy-pasteable curl command, and the inbox folder path with "last scanned".

**7.6 Sources (`/sources`)**: the 8 raw weekly updates, each one next to the normalised items it produced, labelled with its format. This is the "eight formats → one view" proof.

## 8. Ingestion: parsers

Write `parsers/` with format detection plus one parser per format. Each returns `[{project_id, status?, reported_rag?, pct_complete?, forecast_due?, confidence?, milestone_updates?, note}]`.

- **Project matching:** first a regex for codes `\b(RE|SC|TP|MB|CX|IN|FS|PC)-0[1-5]\b`. Otherwise case-insensitive matching against each project's `name` and `aliases` in that function. When the function is known, restrict matching to it.
- **Status/RAG words:** green/on track/🟢/G → Green or On Track; amber/at risk/🟠/A → Amber or At Risk; red/off track/🔴/R → Red or Off Track; blocked → Blocked; done/closed/complete/✅ → Done; not started → Not Started.
- **Numbers:** `NN%` → pct; `conf(idence)? N` or `N/5` → confidence; and in the voice-note format, spelled-out numbers ("forty-seven percent", "two hundred and twelve"). Write a small words-to-number helper.
- **Dates:** handle `2026-11-27`, `10-Jan-27`, `31 Jan 2027`, `15 January`, `Apr-27` (month-end) and `30-Apr-27`. Assume the year from `AS_OF_DATE` when it's missing.
- **Formats:** Email (split into paragraphs, one project per paragraph); CSV tracker (find the header row starting `Ref,`); Jira JSON (`issues[].fields`); Slack (split by message, then by `*bold*` headers); Markdown table; slide export (split by `•` bullets); memo (numbered paragraphs); voice transcript (split by sentence groups around project keywords).
- **Missing fields** keep their previous value. The parser must never blank a field.
- **Test:** `tests/test_parsers.py` runs every file in `weekly_updates/` and compares the output to `expected_extractions.json` (exact on `project_id` set and status; pct ±0; confidence ±0; forecast exact, except month-level sources). Record any tolerance in the test with a comment rather than silently loosening it.
- With `ANTHROPIC_API_KEY` set, offer a "Use Claude" checkbox on the Ingest page. Send the raw text plus a compact project list (id, name, aliases, function), ask for **JSON only** matching the schema, validate it with Pydantic, and fall back to rule-based on any error.

## 9. Automation: the steps that fire without anyone driving them

1. **Scheduled Risk Sweep** (the must-have). An APScheduler job: every `SWEEP_INTERVAL_SECONDS` in demo mode; Mondays 08:30 Asia/Kolkata in prod mode (show the cron string in the UI). Each run: rescore everything, write `risk_snapshots`, compute the top-3 diff against the previous run, write an `automation_runs` row, and write the leadership digest to `digests/digest_<run_id>.md` (top 3, reasons, decisions needed, watch list). It must run once at startup so the page is never empty.
2. **Webhook:** `POST /api/webhooks/update` with header `X-Webhook-Token`. It accepts either the structured payload (see `B_*.json`) or `{"function_code": "...", "raw_text": "..."}`, which goes through the parser. Return the applied changes plus `top3_before` and `top3_after`. Reject a bad token with 401.
3. **Inbox watcher:** a background thread scans `INBOX_DIR` every 5 seconds. For each new file: auto-detect the format, parse it, apply it, move it to `inbox/processed/` with a timestamp prefix, and log the run. Move bad files to `inbox/failed/` with a `.error.txt` file next to them.

Every automated action must be **visible within 5 seconds** on the Leadership and Automation pages: the toast, the run-log row and the updated cards.

## 10. API (JSON)

`GET /api/leadership` (top3, watchlist, mismatches, silent, counts, last_run, next_run_at) · `GET /api/projects` · `GET /api/projects/{id}` · `POST /api/projects/{id}/update` · `POST /api/ingest/parse` · `POST /api/ingest/apply` · `POST /api/webhooks/update` · `GET /api/automation/runs` · `POST /api/automation/sweep/run-now` · `POST /api/automation/sweep/pause|resume` · `GET /api/sources` · `POST /api/admin/reset` · `GET /healthz`.

## 11. Build order (work in this order and commit after each step)

1. Scaffold, config, DB schema, and seed loader from `seed.json` (idempotent; `reset.sh` drops and reloads).
2. `risk.py` plus `tests/test_risk_golden.py`. Make the baseline golden test pass **before** building any UI. Then add tests that apply demo steps A, B and C (using the structured updates in `expected_scores.json → demo_steps[].update`) and match `after_A`, `after_B` and `after_C`.
3. Leadership API and page, All Projects and Detail.
4. Scheduler, `automation_runs`, the polling UI and toast.
5. Parsers plus parser tests, then the Ingest page.
6. Webhook, then the inbox watcher.
7. Sources page, digests, and the README with the demo script.
8. **Verification pass** (section 12).

## 12. Verification you must perform yourself before declaring done

```bash
./reset.sh && ./run.sh &               # start
sleep 3 && curl -s localhost:8000/healthz
curl -s localhost:8000/api/leadership | python3 -m json.tool | head -60    # expect TP-01, SC-02, PC-01
curl -s -X POST localhost:8000/api/ingest/parse -F file=@sample_data/demo_inputs/A_cx_escalation_email.txt
curl -s -X POST localhost:8000/api/ingest/apply  -F file=@sample_data/demo_inputs/A_cx_escalation_email.txt   # top3 → TP-01, SC-02, CX-01
bash sample_data/demo_inputs/curl_examples.sh                                                                 # top3 → SC-02, CX-01, PC-01
cp sample_data/demo_inputs/C_supply_chain_inbox_drop.csv inbox/ && sleep 12
curl -s localhost:8000/api/leadership | python3 -m json.tool | head -30    # top3 → CX-01, PC-01, CX-03
sleep 65 && curl -s localhost:8000/api/automation/runs | head -40          # proves the scheduler fired on its own
pytest -q
```
Paste the real outputs into `DEMO_LOG.md`. If any expectation fails, fix the code. **Do not edit the sample data or the expected scores to make tests pass.** If you believe the golden file disagrees with the spec, stop and tell me which line and why.

If you have a browser tool (Playwright or similar), also load `/`, `/ingest` and `/automation`, take screenshots into `screenshots/`, and confirm there are no console errors.

## 13. README must include a 5-minute live demo script

1. `./reset.sh && ./run.sh` → open http://localhost:8000.
2. **Leadership view:** the top 3 surfaces on its own. TP-01 is #1 even though it's reported **Green** (WATERMELON: 3 overdue milestones, stuck at 62% for 3 weeks, silent for 12 days, go-live in 6 days). SC-02's lab delay ripples into RE-01, CX-02 and MB-01. PC-01's optometrist hiring gap feeds RE-01 and CX-01. Point out MB-03, which is reported **Red** but whose data is fine.
3. **Ingest:** paste email A → preview → Apply → CX-01 jumps into the top 3.
4. **Webhook:** run `curl_examples.sh` → toast appears → TP-01 drops out after its recovery update.
5. **Inbox:** `cp C_*.csv inbox/` → hands off the keyboard → within about 10 seconds SC-02 drops to #4 and CX-03 enters.
6. **Automation page:** watch the countdown hit 0, see sweep #N complete on its own, and open the digest file.
7. `./reset.sh` to run it again.

## 14. Non-goals

Auth/SSO, multi-tenant, mobile polish, real email/Slack integrations, and deployment. Keep these out of scope and mention them in the README as next steps.

## 15. Working style

- Be explicit about any assumption in `ASSUMPTIONS.md` rather than asking me. Keep going until section 2 is fully green.
- Prefer simple, readable code over abstraction. Add a short docstring at the top of each module.
- At the end, give me a summary: the URL, the commands, what you verified (with the actual top-3 at each step), known gaps, and the time it took.
