"""Generates the Lenskart project-tracker sample data pack + reference risk scores."""
import json, csv, datetime as dt, os, copy

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "sample_data")
AS_OF = dt.date(2026, 11, 14)
WEEKS = ["2026-10-05", "2026-10-12", "2026-10-19", "2026-10-26", "2026-11-02", "2026-11-09"]
D = dt.date.fromisoformat

FUNCTIONS = [
    ("RE", "Retail Expansion", "Email (prose)"),
    ("SC", "Supply Chain & Manufacturing", "CSV export of Excel tracker"),
    ("TP", "Technology & Product", "Jira JSON export"),
    ("MB", "Marketing & Brand", "Slack thread transcript"),
    ("CX", "Customer Experience & Omnichannel", "Markdown RAG table"),
    ("IN", "International", "Slide-deck text export"),
    ("FS", "Finance & Strategy", "Formal numbered memo"),
    ("PC", "People & Culture", "Voice-note transcript"),
]

# All names are fictional.
PEOPLE = [
    # id, name, title, function, active, email-handle
    ("P01", "Nandini Sharma", "Chief of Staff, CEO Office", "LEAD", True),
    ("P02", "Karan Malhotra", "Chief Operating Officer", "LEAD", True),
    ("P03", "Meera Iyer", "Chief Financial Officer", "FS", True),
    ("P04", "Arjun Nair", "Chief Technology Officer", "TP", True),
    ("P05", "Rohan Mehta", "Head of Retail Expansion", "RE", True),
    ("P06", "Kavita Rao", "Head of Supply Chain & Manufacturing", "SC", True),
    ("P07", "Sneha Kapoor", "Head of Marketing & Brand", "MB", True),
    ("P08", "Imran Sheikh", "Head of Customer Experience", "CX", True),
    ("P09", "Vikram Singh", "Head of International", "IN", True),
    ("P10", "Ananya Desai", "Chief People Officer", "PC", True),
    ("P11", "Siddharth Joshi", "GM, Store Rollout (North & East)", "RE", True),
    ("P12", "Pooja Reddy", "Manager, Store Design & Refurb", "RE", True),
    ("P13", "Aditya Bansal", "Lead, Franchise Development", "RE", True),
    ("P14", "Ravi Kulkarni", "Plant Head, Bhiwadi Lens Lab", "SC", True),
    ("P15", "Tanvi Agarwal", "Sourcing Manager, Frames", "SC", True),
    ("P16", "Manoj Pillai", "GM, Fulfilment Network", "SC", True),
    ("P17", "Harsh Vardhan", "Engineering Manager, Payments", "TP", True),
    ("P18", "Divya Menon", "Product Lead, Vision & Eye-Test", "TP", True),
    ("P19", "Kunal Shah", "Product Lead, AR Try-On", "TP", True),
    ("P20", "Neha Gupta", "Brand Campaigns Lead", "MB", True),
    ("P21", "Abhishek Rao", "Performance Marketing Lead", "MB", True),
    ("P22", "Farah Khan", "Ops Lead, Home Eye-Test", "CX", True),
    ("P23", "Saurabh Tiwari", "Delivery Experience Manager", "CX", True),
    ("P24", "Lakshmi Narayanan", "Country Manager, KSA", "IN", True),
    ("P25", "Faisal Qureshi", "Ops Manager, GCC Warehouse (left 2026-10-20)", "IN", False),
    ("P26", "Chen Wei Ling", "Country Manager, Singapore", "IN", True),
    ("P27", "Rahul Bhatia", "Head of FP&A", "FS", True),
    ("P28", "Swati Jain", "Procurement Manager, Tech", "FS", True),
    ("P29", "Deepak Chauhan", "Head of Clinical Talent (Optometry)", "PC", True),
    ("P30", "Ritika Sood", "HR Business Partner, Retail", "PC", True),
    ("P31", "Gaurav Sethi", "Workplace & Facilities Manager", "PC", True),
    ("P32", "Isha Verma", "Data Platform Lead", "TP", True),
]

def M(name, due, done=None):
    return {"name": name, "due": due, "done_date": done}

# code, name, priority, owner, sponsor, start, baseline, forecast, pct, budget, spent,
# rag_hist(6), conf_hist(6), pct_hist(6) or None(auto), last_update, deps, milestones, status, kpi, desc, aliases
P = []
def add(**k): P.append(k)

# ---------------- Retail Expansion ----------------
add(code="RE-01", name="H2 store rollout - 120 new stores (Tier 2/3)", priority="P0", owner="P11", sponsor="P05",
    start="2026-07-01", baseline="2027-03-31", forecast="2027-03-31", pct=57, budget=96.0, spent=52.0,
    rag="GGGGGG", conf=[4,4,4,4,4,4], pcth=[34,39,44,49,53,57], last="2026-11-12", deps=["PC-01","SC-02"],
    ms=[M("40 stores live", "2026-09-30", "2026-09-28"), M("70 stores live", "2026-11-30"), M("120 stores live", "2027-03-31")],
    kpi={"metric":"Stores opened","target":120,"actual":68,"unit":"stores"},
    desc="Open 120 company-owned stores across Tier 2/3 cities in H2 FY27. Each store needs 2 certified optometrists and lens-lab fulfilment within 72h.",
    aliases=["H2 rollout","120 stores","new store openings","store rollout"])
add(code="RE-02", name="Store refurbishment 3.0 - 200 legacy stores", priority="P1", owner="P12", sponsor="P05",
    start="2026-06-01", baseline="2026-12-31", forecast="2027-01-15", pct=71, budget=30.0, spent=24.0,
    rag="GGGAAA", conf=[4,4,3,3,3,3], pcth=[48,53,58,63,67,71], last="2026-11-12", deps=[],
    ms=[M("100 stores refurbished","2026-09-15","2026-09-14"), M("150 stores refurbished","2026-10-31","2026-11-06"), M("200 stores refurbished","2026-12-31")],
    kpi={"metric":"Stores refurbished","target":200,"actual":152,"unit":"stores"},
    desc="New fixture kit, eye-test room redesign and digital shelf screens in 200 pre-2020 stores.",
    aliases=["refurb","refurbishment","store 3.0"])
add(code="RE-03", name="Franchise (FOFO) partner onboarding - 60 partners", priority="P1", owner="P13", sponsor="P05",
    start="2026-07-15", baseline="2027-02-28", forecast="2027-02-28", pct=64, budget=4.0, spent=2.3,
    rag="GGGGGG", conf=[4,4,4,4,5,5], pcth=[36,42,48,54,59,64], last="2026-11-12", deps=["FS-04"],
    ms=[M("30 partners signed","2026-10-15","2026-10-11"), M("45 partners signed","2026-12-15"), M("60 partners signed","2027-02-28")],
    kpi={"metric":"Partners signed","target":60,"actual":38,"unit":"partners"},
    desc="Franchise-owned, franchise-operated partner stores in towns below 5 lakh population.",
    aliases=["FOFO","franchise onboarding","franchise partners"])
add(code="RE-04", name="Mall kiosk pilot - Mumbai & Delhi (15 kiosks)", priority="P2", owner="P11", sponsor="P05",
    start="2026-08-01", baseline="2026-10-31", forecast="2026-10-30", pct=100, budget=2.5, spent=2.4,
    rag="GGGGGG", conf=[4,4,5,5,5,5], pcth=[70,80,90,100,100,100], last="2026-11-02", deps=[], status="Done",
    ms=[M("15 kiosks live","2026-10-31","2026-10-30")],
    kpi={"metric":"Kiosks live","target":15,"actual":15,"unit":"kiosks"},
    desc="Sunglass and contact-lens kiosks in high-footfall malls. Pilot closed; scale decision in Q4 review.",
    aliases=["kiosk pilot","mall kiosks"])
add(code="RE-05", name="Cluster manager P&L dashboard rollout", priority="P2", owner="P13", sponsor="P05",
    start="2026-12-01", baseline="2027-02-15", forecast="2027-02-15", pct=0, budget=0.8, spent=0.0,
    rag="GGGGGG", conf=[4,4,4,4,4,4], pcth=[0,0,0,0,0,0], last="2026-11-12", deps=["FS-02"], status="Not Started",
    ms=[M("Pilot with 5 clusters","2027-01-10"), M("All 42 clusters","2027-02-15")],
    kpi={"metric":"Clusters live","target":42,"actual":0,"unit":"clusters"},
    desc="Weekly store-level P&L for cluster managers, built on FS-02 unit-economics model.",
    aliases=["P&L dashboard","cluster dashboard"])

# ---------------- Supply Chain ----------------
add(code="SC-01", name="Frame sourcing shift - 40% China to India vendors", priority="P1", owner="P15", sponsor="P06",
    start="2026-04-01", baseline="2026-12-31", forecast="2027-01-10", pct=78, budget=12.0, spent=8.8,
    rag="GGGGAA", conf=[4,4,4,4,3,3], pcth=[58,62,66,70,74,78], last="2026-11-11", deps=[],
    ms=[M("12 Indian vendors qualified","2026-08-31","2026-08-27"), M("30% volume shifted","2026-10-31","2026-11-04"), M("40% volume shifted","2026-12-31")],
    kpi={"metric":"Share of frames from Indian vendors","target":40,"actual":31,"unit":"%"},
    desc="De-risk tariff exposure by moving 40% of frame volume to qualified Indian vendors.",
    aliases=["frame sourcing","vendor shift","China+1"])
add(code="SC-02", name="Bhiwadi lens lab Phase 2 - capacity 1.2L to 2L lenses/day", priority="P0", owner="P14", sponsor="P06",
    start="2026-05-15", baseline="2026-11-30", forecast="2027-01-10", pct=66, budget=85.0, spent=74.0,
    rag="GGGAAA", conf=[4,4,3,3,2,2], pcth=[48,53,58,61,64,66], last="2026-11-10", deps=[],
    ms=[M("Civil & clean-room works complete","2026-08-31","2026-08-29"),
        M("Coating line delivered to site","2026-10-15","2026-11-03"),
        M("Coating line installed & commissioned","2026-11-10"),
        M("Trial production 50k lenses/day","2026-11-20"),
        M("Full capacity 2L lenses/day","2026-11-30")],
    kpi={"metric":"Lens lab capacity","target":200000,"actual":120000,"unit":"lenses/day"},
    desc="Second coating & edging line at Bhiwadi. Needed for Q4 store openings, the 48-hour delivery promise and the Dec-Jan sale peak.",
    aliases=["Bhiwadi","lens lab","Phase 2","coating line","capacity expansion"])
add(code="SC-03", name="Hyderabad regional fulfilment centre", priority="P1", owner="P16", sponsor="P06",
    start="2026-06-15", baseline="2027-01-31", forecast="2027-01-31", pct=58, budget=22.0, spent=12.1,
    rag="GGGGGG", conf=[4,4,4,4,4,4], pcth=[33,38,43,48,53,58], last="2026-11-11", deps=[],
    ms=[M("Lease signed","2026-07-31","2026-07-25"), M("Racking & WMS go-live","2026-12-15"), M("First outbound shipment","2027-01-31")],
    kpi={"metric":"South India orders served from HYD","target":60,"actual":0,"unit":"%"},
    desc="Cut South India delivery time by a day with a 1.1 lakh sq ft fulfilment centre.",
    aliases=["Hyderabad FC","HYD warehouse","fulfilment centre"])
add(code="SC-04", name="Contact lens cold-chain SKU expansion", priority="P2", owner="P16", sponsor="P06",
    start="2026-08-01", baseline="2026-12-15", forecast="2026-12-22", pct=60, budget=3.0, spent=1.9,
    rag="GGGGGA", conf=[4,4,4,4,4,3], pcth=[25,33,41,48,55,60], last="2026-11-11", deps=[],
    ms=[M("Temperature-controlled storage at 3 hubs","2026-10-31","2026-10-29"), M("120 new SKUs listed","2026-12-15")],
    kpi={"metric":"New CL SKUs live","target":120,"actual":64,"unit":"SKUs"},
    desc="Add 120 colour and toric contact-lens SKUs needing 2-8C storage.",
    aliases=["cold chain","contact lens SKUs"])
add(code="SC-05", name="Returns & refurbishment loop for frames", priority="P2", owner="P15", sponsor="P06",
    start="2026-07-01", baseline="2026-11-15", forecast="2026-11-10", pct=100, budget=1.5, spent=1.4,
    rag="GGGGGG", conf=[4,4,5,5,5,5], pcth=[75,84,90,96,100,100], last="2026-11-11", deps=[], status="Done",
    ms=[M("Refurb cell live at Bhiwadi","2026-11-15","2026-11-10")],
    kpi={"metric":"Returned frames resold","target":30,"actual":33,"unit":"%"},
    desc="Inspect, refurbish and resell returned frames via outlet channel.",
    aliases=["returns loop","refurb frames"])

# ---------------- Technology & Product ----------------
add(code="TP-01", name="Checkout & payments re-platform (new PG + UPI Autopay)", priority="P0", owner="P17", sponsor="P04",
    start="2026-07-15", baseline="2026-11-20", forecast="2026-11-20", pct=62, budget=18.0, spent=13.0,
    rag="GGGGGG", conf=[4,4,4,4,4,4], pcth=[41,52,62,62,62,62], last="2026-11-02", deps=[],
    ms=[M("New PG contract signed","2026-08-30","2026-08-28"),
        M("Sandbox integration complete","2026-09-30","2026-10-03"),
        M("UAT sign-off","2026-10-31"),
        M("PCI-DSS security audit passed","2026-11-07"),
        M("Load test at 5x peak (year-end sale)","2026-11-12"),
        M("Production go-live","2026-11-20")],
    kpi={"metric":"Checkout success rate","target":96.5,"actual":92.1,"unit":"%"},
    desc="Replace legacy payment gateway, add UPI Autopay for Gold membership renewals. Must be live before the Dec 15 year-end sale.",
    aliases=["checkout","payments","payment gateway","PG migration","UPI Autopay"])
add(code="TP-02", name="AI remote eye test v2 (in-app)", priority="P1", owner="P18", sponsor="P04",
    start="2026-06-01", baseline="2027-01-31", forecast="2027-01-31", pct=63, budget=14.0, spent=8.0,
    rag="GGGGGG", conf=[4,4,4,4,4,4], pcth=[40,45,50,54,59,63], last="2026-11-13", deps=[],
    ms=[M("Clinical validation study (n=2,000)","2026-10-15","2026-10-12"), M("Beta to 50k users","2026-12-10"), M("GA","2027-01-31")],
    kpi={"metric":"Refraction accuracy vs optometrist","target":95,"actual":93.4,"unit":"%"},
    desc="Phone-based refraction test with optometrist review, for customers far from a store.",
    aliases=["remote eye test","eye test v2","AI eye test"])
add(code="TP-03", name="3D / AR virtual try-on 3.0", priority="P1", owner="P19", sponsor="P04",
    start="2026-07-01", baseline="2026-12-10", forecast="2026-12-24", pct=58, budget=6.0, spent=3.9,
    rag="GGGAAA", conf=[4,4,3,3,3,3], pcth=[30,37,44,50,54,58], last="2026-11-13", deps=[],
    ms=[M("New face-mesh model trained","2026-10-20","2026-10-26"), M("iOS + Android beta","2026-11-25"), M("Live for 100% catalogue","2026-12-10")],
    kpi={"metric":"Try-on to cart conversion","target":14,"actual":11.2,"unit":"%"},
    desc="Realistic lens tint and frame-fit rendering; covers 100% of catalogue.",
    aliases=["AR try-on","virtual try-on","3D try on"])
add(code="TP-04", name="Store POS migration to cloud", priority="P1", owner="P17", sponsor="P04",
    start="2026-05-01", baseline="2026-12-31", forecast="2026-12-31", pct=80, budget=9.0, spent=6.6,
    rag="GGGGGG", conf=[4,4,4,4,4,4], pcth=[62,66,70,73,77,80], last="2026-11-13", deps=[],
    ms=[M("1,000 stores migrated","2026-09-30","2026-09-29"), M("2,000 stores migrated","2026-11-30"), M("All 2,600 stores","2026-12-31")],
    kpi={"metric":"Stores on cloud POS","target":2600,"actual":2080,"unit":"stores"},
    desc="Retire on-prem POS servers; enables real-time inventory across stores.",
    aliases=["POS migration","cloud POS"])
add(code="TP-05", name="Customer data platform - single customer view", priority="P2", owner="P32", sponsor="P04",
    start="2026-09-01", baseline="2027-03-31", forecast="2027-04-30", pct=12, budget=11.0, spent=0.9,
    rag="GGAARR", conf=[4,4,3,3,2,2], pcth=[5,8,10,12,12,12], last="2026-11-13", deps=["FS-03"], status="Blocked",
    ms=[M("Vendor selected & contract signed","2026-10-31"), M("Identity resolution MVP","2027-01-31")],
    kpi={"metric":"Customer profiles unified","target":30,"actual":0,"unit":"million"},
    desc="Unify app, store and eye-test records into one profile. Blocked on vendor contract (FS-03).",
    aliases=["CDP","single customer view","data platform"])

# ---------------- Marketing & Brand ----------------
add(code="MB-01", name="Wedding-season & year-end sale campaign (Dec 15 - Jan 5)", priority="P0", owner="P20", sponsor="P07",
    start="2026-10-01", baseline="2026-12-15", forecast="2026-12-15", pct=55, budget=48.0, spent=19.0,
    rag="GGGGGG", conf=[4,4,4,4,4,4], pcth=[10,20,30,40,48,55], last="2026-11-13", deps=["TP-01","SC-02"],
    ms=[M("Creative routes approved","2026-10-25","2026-10-24"), M("Media plan locked","2026-11-20"), M("Campaign live","2026-12-15")],
    kpi={"metric":"Sale-period GMV target","target":620,"actual":0,"unit":"INR cr"},
    desc="Biggest sale of the year. Depends on new checkout (TP-01) and lens-lab capacity (SC-02) to handle 3x order volume.",
    aliases=["year-end sale","wedding season campaign","sale campaign","YES campaign"])
add(code="MB-02", name="Micro-influencer program - 500 creators", priority="P2", owner="P21", sponsor="P07",
    start="2026-08-15", baseline="2027-01-31", forecast="2027-01-31", pct=52, budget=5.0, spent=2.4,
    rag="GGGGGG", conf=[4,4,4,4,4,4], pcth=[20,27,34,40,46,52], last="2026-11-13", deps=[],
    ms=[M("250 creators onboarded","2026-11-15","2026-11-12"), M("500 creators onboarded","2027-01-31")],
    kpi={"metric":"Creators onboarded","target":500,"actual":262,"unit":"creators"},
    desc="Regional creators in 40 cities for try-on content.",
    aliases=["influencer program","creators"])
add(code="MB-03", name="Brand refresh film - 'See the World Differently'", priority="P1", owner="P20", sponsor="P07",
    start="2026-09-01", baseline="2027-01-20", forecast="2027-01-20", pct=48, budget=16.0, spent=7.0,
    rag="GGRRRR", conf=[4,3,3,3,3,3], pcth=[15,22,30,37,43,48], last="2026-11-13", deps=[],
    ms=[M("New agency on board","2026-10-01","2026-09-30"), M("Script & director locked","2026-11-05","2026-11-04"), M("Shoot complete","2026-12-10"), M("Release","2027-01-20")],
    kpi={"metric":"Milestones on time","target":4,"actual":2,"unit":"of 4"},
    desc="New brand film + digital cut-downs. Owner flags RED due to agency change, but all milestones are on time.",
    aliases=["brand film","brand refresh","See the World"])
add(code="MB-04", name="Regional-language performance marketing (8 languages)", priority="P2", owner="P21", sponsor="P07",
    start="2026-07-01", baseline="2026-12-31", forecast="2026-12-31", pct=70, budget=9.0, spent=6.1,
    rag="GGGGGG", conf=[4,4,4,4,4,4], pcth=[45,50,55,60,65,70], last="2026-11-13", deps=[],
    ms=[M("5 languages live","2026-09-30","2026-09-26"), M("8 languages live","2026-12-31")],
    kpi={"metric":"CAC in regional campaigns","target":410,"actual":395,"unit":"INR"},
    desc="Tamil, Telugu, Kannada, Malayalam, Marathi, Bengali, Gujarati, Punjabi ad creatives.",
    aliases=["regional marketing","vernacular ads"])
add(code="MB-05", name="Gold membership messaging revamp", priority="P2", owner="P21", sponsor="P07",
    start="2026-08-01", baseline="2026-10-31", forecast="2026-10-28", pct=100, budget=1.0, spent=0.9,
    rag="GGGGGG", conf=[5,5,5,5,5,5], pcth=[80,90,100,100,100,100], last="2026-11-02", deps=[], status="Done",
    ms=[M("New messaging live in app & stores","2026-10-31","2026-10-28")],
    kpi={"metric":"Gold sign-up rate","target":18,"actual":19.5,"unit":"%"},
    desc="Rewrote Gold value proposition across app, web and store collateral.",
    aliases=["Gold messaging"])

# ---------------- Customer Experience ----------------
add(code="CX-01", name="Home eye-test service - expand 25 to 40 cities", priority="P0", owner="P22", sponsor="P08",
    start="2026-08-15", baseline="2027-01-31", forecast="2027-01-31", pct=48, budget=20.0, spent=9.5,
    rag="GGGGGG", conf=[4,4,4,4,4,4], pcth=[18,24,30,36,42,48], last="2026-11-12", deps=["PC-01"],
    ms=[M("Fleet partner contract renewal signed","2026-11-01"), M("32 cities live","2026-11-30"), M("40 cities live","2027-01-31")],
    kpi={"metric":"Cities with home eye-test","target":40,"actual":29,"unit":"cities"},
    desc="Optometrist-in-a-van home visits. Runs on a third-party vehicle fleet partner + PC-01 optometrists.",
    aliases=["home eye test","HTO","home try-on","home eye-test expansion"])
add(code="CX-02", name="48-hour delivery promise - expand to 300 cities", priority="P1", owner="P23", sponsor="P08",
    start="2026-07-01", baseline="2026-12-31", forecast="2027-01-10", pct=60, budget=7.0, spent=4.2,
    rag="GGGGAA", conf=[4,4,4,4,3,3], pcth=[35,40,45,50,55,60], last="2026-11-12", deps=["SC-02"],
    ms=[M("200 cities on 48h promise","2026-10-31","2026-10-30"), M("300 cities on 48h promise","2026-12-31")],
    kpi={"metric":"Orders delivered in 48h (eligible cities)","target":90,"actual":86,"unit":"%"},
    desc="Prescription glasses delivered within 48 hours. Needs lab capacity from SC-02.",
    aliases=["48 hour delivery","48h promise","fast delivery"])
add(code="CX-03", name="Store NPS recovery - cut eye-test wait times", priority="P1", owner="P08", sponsor="P02",
    start="2026-08-01", baseline="2026-12-31", forecast="2027-02-28", pct=35, budget=3.0, spent=1.6,
    rag="GGAAAA", conf=[4,4,3,3,2,2], pcth=[15,20,25,30,33,35], last="2026-11-12", deps=[],
    ms=[M("Queue-management app in 50 pilot stores","2026-10-31"), M("NPS 68 in pilot stores","2026-11-30"), M("Chain-wide NPS 72","2026-12-31")],
    kpi={"metric":"Store NPS","target":72,"actual":64,"unit":"NPS"},
    desc="Store NPS fell from 71 to 64 as eye-test waits crossed 35 minutes on weekends.",
    aliases=["NPS","wait times","store NPS"])
add(code="CX-04", name="Gold membership auto-renewal flow", priority="P1", owner="P23", sponsor="P08",
    start="2026-09-15", baseline="2027-01-15", forecast="2027-01-15", pct=40, budget=2.0, spent=0.8,
    rag="GGGGGG", conf=[4,4,4,4,4,4], pcth=[10,16,22,28,34,40], last="2026-11-12", deps=["TP-01"],
    ms=[M("Renewal journey designed","2026-10-31","2026-10-29"), M("Auto-renew live on UPI Autopay","2027-01-15")],
    kpi={"metric":"Gold renewal rate","target":55,"actual":41,"unit":"%"},
    desc="One-tap renewal using UPI Autopay from TP-01.",
    aliases=["auto renewal","Gold renewal"])
add(code="CX-05", name="WhatsApp support & order-tracking bot", priority="P2", owner="P22", sponsor="P08",
    start="2026-08-01", baseline="2026-12-15", forecast="2026-12-15", pct=72, budget=1.2, spent=0.7,
    rag="GGGGGG", conf=[4,4,4,4,4,4], pcth=[42,48,54,60,66,72], last="2026-11-12", deps=[],
    ms=[M("Order tracking live","2026-10-15","2026-10-14"), M("Returns & exchanges self-serve","2026-12-15")],
    kpi={"metric":"Tickets deflected","target":40,"actual":31,"unit":"%"},
    desc="Self-serve order status, returns and store-appointment booking on WhatsApp.",
    aliases=["WhatsApp bot","support bot"])

# ---------------- International ----------------
add(code="IN-01", name="Saudi Arabia expansion - 20 stores by Mar 2027", priority="P1", owner="P24", sponsor="P09",
    start="2026-06-01", baseline="2027-03-31", forecast="2027-04-30", pct=30, budget=38.0, spent=13.0,
    rag="GGGAAA", conf=[4,4,3,3,3,3], pcth=[14,18,21,25,28,30], last="2026-11-11", deps=[],
    ms=[M("Municipal (Balady) licences for first 8 sites","2026-10-31"), M("8 stores live","2026-12-31"), M("20 stores live","2027-03-31")],
    kpi={"metric":"KSA stores live","target":20,"actual":3,"unit":"stores"},
    desc="Riyadh, Jeddah, Dammam. Licensing for 5 of 8 sites still pending.",
    aliases=["KSA","Saudi","Saudi expansion","Riyadh"])
add(code="IN-02", name="Dubai (JAFZA) GCC regional warehouse", priority="P2", owner="P25", sponsor="P09",
    start="2026-06-15", baseline="2026-12-15", forecast="2027-01-31", pct=40, budget=8.0, spent=4.4,
    rag="GAAAAA", conf=[4,3,3,3,3,3], pcth=[25,32,38,40,40,40], last="2026-10-22", deps=[],
    ms=[M("Free-zone licence & lease","2026-08-31","2026-08-30"), M("WMS integration with India","2026-10-31"), M("First GCC shipment from Dubai","2026-12-15")],
    kpi={"metric":"GCC orders fulfilled from Dubai","target":70,"actual":0,"unit":"%"},
    desc="Regional stock point for UAE, KSA, Oman. Owner left the company on Oct 20; no successor named.",
    aliases=["Dubai warehouse","JAFZA","GCC warehouse"])
add(code="IN-03", name="Japan - Owndays co-brand frame collection", priority="P2", owner="P09", sponsor="P09",
    start="2026-08-01", baseline="2027-02-28", forecast="2027-02-28", pct=45, budget=4.0, spent=1.6,
    rag="GGGGGG", conf=[4,4,4,4,4,4], pcth=[20,25,30,35,40,45], last="2026-11-11", deps=[],
    ms=[M("Designs approved","2026-10-30","2026-10-28"), M("Samples from Indian vendors","2026-12-20"), M("Launch in 50 Japan stores","2027-02-28")],
    kpi={"metric":"Styles approved","target":24,"actual":24,"unit":"styles"},
    desc="Co-designed collection manufactured in India, sold through Japan stores.",
    aliases=["Japan collection","Owndays co-brand"])
add(code="IN-04", name="Singapore omnichannel launch (app + 12 stores)", priority="P1", owner="P26", sponsor="P09",
    start="2026-05-01", baseline="2026-12-31", forecast="2026-12-31", pct=76, budget=15.0, spent=10.9,
    rag="GGGGGG", conf=[4,4,4,4,4,4], pcth=[56,60,64,68,72,76], last="2026-11-11", deps=[],
    ms=[M("App localised (SGD, PayNow)","2026-09-30","2026-09-30"), M("8 stores on unified inventory","2026-11-30"), M("All 12 stores","2026-12-31")],
    kpi={"metric":"Online share of SG revenue","target":20,"actual":13,"unit":"%"},
    desc="Click-and-collect, unified inventory and app checkout for Singapore.",
    aliases=["Singapore","SG omnichannel"])
add(code="IN-05", name="US online pilot - contact lenses", priority="P2", owner="P09", sponsor="P09",
    start="2027-01-15", baseline="2027-06-30", forecast="2027-06-30", pct=0, budget=6.0, spent=0.0,
    rag="GGGGGG", conf=[3,3,3,3,3,3], pcth=[0,0,0,0,0,0], last="2026-11-11", deps=[], status="Not Started",
    ms=[M("Board approval","2027-01-15")],
    kpi={"metric":"US monthly orders","target":5000,"actual":0,"unit":"orders"},
    desc="D2C contact-lens subscription pilot in the US. Awaiting board approval.",
    aliases=["US pilot","USA contact lens"])

# ---------------- Finance & Strategy ----------------
add(code="FS-01", name="Q2 FY27 results & analyst day", priority="P0", owner="P27", sponsor="P03",
    start="2026-09-15", baseline="2026-11-07", forecast="2026-11-06", pct=100, budget=0.6, spent=0.55,
    rag="GGGGGG", conf=[5,5,5,5,5,5], pcth=[40,60,80,95,100,100], last="2026-11-10", deps=[], status="Done",
    ms=[M("Board approval of results","2026-11-05","2026-11-05"), M("Analyst day","2026-11-07","2026-11-06")],
    kpi={"metric":"Results filed on time","target":1,"actual":1,"unit":"yes/no"},
    desc="Quarterly results filing and analyst day. Completed.",
    aliases=["Q2 results","analyst day"])
add(code="FS-02", name="Store unit-economics model refresh", priority="P1", owner="P27", sponsor="P03",
    start="2026-09-01", baseline="2026-11-30", forecast="2026-11-30", pct=82, budget=0.4, spent=0.3,
    rag="GGGGGG", conf=[4,4,4,4,4,4], pcth=[40,50,60,68,75,82], last="2026-11-10", deps=[],
    ms=[M("Data model signed off","2026-10-15","2026-10-14"), M("CFO review","2026-11-30")],
    kpi={"metric":"Store cohorts modelled","target":6,"actual":5,"unit":"cohorts"},
    desc="Payback and EBITDA by store vintage, city tier and format.",
    aliases=["unit economics","store model"])
add(code="FS-03", name="CDP vendor procurement & contract", priority="P2", owner="P28", sponsor="P03",
    start="2026-08-15", baseline="2026-10-31", forecast="2026-12-15", pct=70, budget=0.2, spent=0.1,
    rag="GGAAAA", conf=[4,4,3,3,3,3], pcth=[40,50,60,65,68,70], last="2026-11-10", deps=[],
    ms=[M("RFP responses evaluated","2026-09-30","2026-10-04"), M("Contract signed","2026-10-31")],
    kpi={"metric":"Contract signed","target":1,"actual":0,"unit":"yes/no"},
    desc="Negotiating data-residency clauses with shortlisted vendor. Blocks TP-05.",
    aliases=["CDP procurement","CDP contract","vendor contract"])
add(code="FS-04", name="GST e-invoicing for franchise partners", priority="P1", owner="P27", sponsor="P03",
    start="2026-09-01", baseline="2026-12-31", forecast="2026-12-31", pct=60, budget=0.8, spent=0.4,
    rag="GGGGGG", conf=[4,4,4,4,4,4], pcth=[20,28,36,44,52,60], last="2026-11-10", deps=[],
    ms=[M("ERP integration tested","2026-11-15"), M("All partners live","2026-12-31")],
    kpi={"metric":"Partners on e-invoicing","target":100,"actual":45,"unit":"%"},
    desc="Automated e-invoices for franchise stock transfers.",
    aliases=["e-invoicing","GST invoicing"])
add(code="FS-05", name="Opex savings - INR 40 cr in FY27", priority="P1", owner="P03", sponsor="P02",
    start="2026-04-01", baseline="2027-03-31", forecast="2027-03-31", pct=55, budget=0.0, spent=0.0,
    rag="GGGAAA", conf=[4,4,3,3,3,3], pcth=[40,43,46,49,52,55], last="2026-11-10", deps=[],
    ms=[M("INR 20 cr locked in","2026-09-30","2026-10-10"), M("INR 30 cr locked in","2026-12-31"), M("INR 40 cr locked in","2027-03-31")],
    kpi={"metric":"Savings locked in","target":40,"actual":22,"unit":"INR cr"},
    desc="Rent renegotiation, freight consolidation and cloud cost cuts.",
    aliases=["cost savings","opex savings","cost optimisation"])

# ---------------- People & Culture ----------------
add(code="PC-01", name="Optometrist hiring & certification - 450 for H2 openings", priority="P0", owner="P29", sponsor="P10",
    start="2026-07-01", baseline="2026-12-31", forecast="2027-01-31", pct=47, budget=9.0, spent=4.5,
    rag="GGAAAA", conf=[4,3,3,3,2,2], pcth=[30,34,38,42,45,47], last="2026-11-11", deps=[],
    ms=[M("150 hired","2026-09-30","2026-10-09"), M("300 hired","2026-10-31"), M("Certification batch 3 complete","2026-11-10"), M("450 hired & certified","2026-12-31")],
    kpi={"metric":"Optometrists hired & certified","target":450,"actual":212,"unit":"people"},
    desc="Every new store needs 2 certified optometrists; home eye-test vans need 1 each. Hiring run-rate is ~22/week vs ~40 needed.",
    aliases=["optometrist hiring","optom hiring","clinical hiring","optometrists"])
add(code="PC-02", name="Store manager leadership academy", priority="P2", owner="P30", sponsor="P10",
    start="2026-08-01", baseline="2027-01-31", forecast="2027-01-31", pct=50, budget=2.0, spent=0.9,
    rag="GGGGGG", conf=[4,4,4,4,4,4], pcth=[20,26,32,38,44,50], last="2026-11-11", deps=[],
    ms=[M("Cohort 1 (120 managers) graduated","2026-10-31","2026-10-31"), M("Cohort 2 graduated","2027-01-31")],
    kpi={"metric":"Managers trained","target":240,"actual":120,"unit":"managers"},
    desc="6-week programme on P&L, team leadership and clinical quality.",
    aliases=["leadership academy","store manager training"])
add(code="PC-03", name="H1 performance cycle & OKR reviews", priority="P1", owner="P30", sponsor="P10",
    start="2026-09-15", baseline="2026-10-31", forecast="2026-10-30", pct=100, budget=0.1, spent=0.1,
    rag="GGGGGG", conf=[5,5,5,5,5,5], pcth=[50,75,90,100,100,100], last="2026-11-02", deps=[], status="Done",
    ms=[M("Calibration complete","2026-10-31","2026-10-30")],
    kpi={"metric":"Reviews completed","target":100,"actual":99,"unit":"%"},
    desc="Mid-year reviews for corporate staff. Completed.",
    aliases=["performance cycle","OKR review"])
add(code="PC-04", name="Gurugram HQ floor consolidation", priority="P2", owner="P31", sponsor="P10",
    start="2026-08-01", baseline="2026-11-30", forecast="2027-01-15", pct=35, budget=3.5, spent=1.2,
    rag="GGAARR", conf=[4,4,3,3,2,2], pcth=[20,28,35,35,35,35], last="2026-11-11", deps=[], status="Blocked",
    ms=[M("Landlord NOC for fit-out","2026-10-15"), M("Teams moved","2026-11-30")],
    kpi={"metric":"Floors vacated","target":2,"actual":0,"unit":"floors"},
    desc="Move from 4 floors to 2. Blocked on landlord NOC. Low business impact.",
    aliases=["HQ move","office move","floor consolidation"])
add(code="PC-05", name="Store staff attrition reduction (<35% annualised)", priority="P1", owner="P30", sponsor="P10",
    start="2026-06-01", baseline="2027-03-31", forecast="2027-03-31", pct=40, budget=6.0, spent=2.9,
    rag="GGGAAA", conf=[4,4,3,3,3,3], pcth=[18,23,28,32,36,40], last="2026-11-11", deps=[],
    ms=[M("New incentive plan live","2026-09-30","2026-09-30"), M("Attrition below 38%","2026-12-31"), M("Attrition below 35%","2027-03-31")],
    kpi={"metric":"Annualised store attrition","target":35,"actual":41,"unit":"%"},
    desc="Incentive redesign, shift predictability and career paths for store associates.",
    aliases=["attrition","staff attrition","retention"])

RAG = {"G": "Green", "A": "Amber", "R": "Red"}
STATUS_FROM_RAG = {"G": "On Track", "A": "At Risk", "R": "Off Track"}
NOTES = {}  # filled from weekly updates below

people_by_id = {p[0]: p for p in PEOPLE}

def build_projects():
    out = []
    for k in P:
        fcode = k["code"][:2]
        status = k.get("status") or STATUS_FROM_RAG[k["rag"][-1]]
        # forecast history: slippers ramp from baseline to forecast over the window
        b, f = D(k["baseline"]), D(k["forecast"])
        slip = (f - b).days
        hist = []
        for i, w in enumerate(WEEKS):
            r = k["rag"][i]
            if slip > 0:
                # slip appears when RAG first turns non-green, otherwise last 3 weeks
                first_bad = next((j for j, c in enumerate(k["rag"]) if c != "G"), 3)
                frac = 0 if i < first_bad else (i - first_bad + 1) / (6 - first_bad)
                fd = b + dt.timedelta(days=round(slip * frac))
            else:
                fd = f if i >= 3 else b if slip == 0 else f
            # TP-01 and IN-02 go stale: no new entries after last update
            if D(w) > D(k["last"]):
                continue
            hist.append({"week_of": w, "reported_rag": RAG[r], "reported_status": k.get("status") if (i == 5 and k.get("status")) else STATUS_FROM_RAG[r],
                         "pct_complete": k["pcth"][i], "forecast_due": fd.isoformat(), "confidence": k["conf"][i],
                         "note": NOTES.get((k["code"], w), ""), "source": f"{fcode} weekly update"})
        for m in k["ms"]:
            m["status"] = "Done" if m["done_date"] else ("Overdue" if D(m["due"]) < AS_OF else "Open")
            if m["done_date"] and D(m["done_date"]) > D(m["due"]):
                m["status"] = "Done (late)"
        out.append({
            "id": k["code"], "name": k["name"], "function_code": fcode,
            "function": next(n for c, n, _ in FUNCTIONS if c == fcode),
            "description": k["desc"], "aliases": k["aliases"], "priority": k["priority"],
            "owner_id": k["owner"], "owner_name": people_by_id[k["owner"]][1],
            "exec_sponsor_id": k["sponsor"], "exec_sponsor_name": people_by_id[k["sponsor"]][1],
            "status": status, "reported_rag": RAG[k["rag"][-1]] if k.get("status") != "Done" else "Green",
            "start_date": k["start"], "baseline_due": k["baseline"], "forecast_due": k["forecast"],
            "pct_complete": k["pct"], "budget_inr_cr": k["budget"], "spent_inr_cr": k["spent"],
            "confidence": k["conf"][-1], "last_update_date": k["last"], "dependencies": k["deps"],
            "kpi": k["kpi"], "milestones": k["ms"], "weekly_history": hist,
        })
    return out

# ---------------- Reference risk engine (spec in PROMPT.md section 6) ----------------
W = {"P0": 1.0, "P1": 0.8, "P2": 0.55}

def base_signals(p, people, dependents):
    s = []  # (signal_key, points, explanation)
    if p["status"] in ("Done",):
        return s
    as_of = AS_OF
    slip = (D(p["forecast_due"]) - D(p["baseline_due"])).days
    if slip > 0:
        s.append(("schedule_slip", min(30, slip * 0.75), f"Forecast {p['forecast_due']} is {slip} days past baseline {p['baseline_due']}"))
    od = [m for m in p["milestones"] if not m["done_date"] and D(m["due"]) < as_of]
    if od:
        s.append(("overdue_milestones", min(24, 8 * len(od)), f"{len(od)} overdue milestone(s): " + "; ".join(f"{m['name']} (due {m['due']})" for m in od)))
    st, bd = D(p["start_date"]), D(p["baseline_due"])
    if as_of > st and p["status"] != "Not Started":
        exp = min(100, (as_of - st).days / max(1, (bd - st).days) * 100)
        gap = exp - p["pct_complete"]
        if gap > 10:
            s.append(("progress_gap", round(min(15, (gap - 10) * 0.5), 2), f"{p['pct_complete']}% complete vs ~{exp:.0f}% expected by now"))
    h = p["weekly_history"]
    if len(h) >= 3 and h[-1]["pct_complete"] == h[-2]["pct_complete"] == h[-3]["pct_complete"] and p["pct_complete"] < 100 and p["status"] != "Not Started":
        s.append(("stalled_progress", 10, f"% complete stuck at {p['pct_complete']}% for 3 consecutive updates"))
    days = (as_of - D(p["last_update_date"])).days
    if days > 21:
        s.append(("stale_update", 15, f"No update for {days} days"))
    elif days > 10:
        s.append(("stale_update", 10, f"No update for {days} days"))
    confs = [x["confidence"] for x in h]
    if confs and max(confs) - p["confidence"] >= 2:
        s.append(("confidence_drop", 8, f"Owner confidence fell from {max(confs)} to {p['confidence']} (of 5)"))
    if p["confidence"] <= 2:
        s.append(("low_confidence", 5, f"Owner confidence is {p['confidence']}/5"))
    if p["budget_inr_cr"] > 0 and (p["spent_inr_cr"] / p["budget_inr_cr"]) - p["pct_complete"] / 100 > 0.15:
        s.append(("budget_burn", 8, f"{p['spent_inr_cr'] / p['budget_inr_cr'] * 100:.0f}% of budget spent for {p['pct_complete']}% complete"))
    owner = people.get(p["owner_id"])
    if not owner or not owner["active"]:
        s.append(("no_active_owner", 12, f"Owner {p['owner_name']} is no longer active; no successor assigned"))
    dtf = (D(p["forecast_due"]) - as_of).days
    if 0 <= dtf <= 14 and p["pct_complete"] < 85:
        s.append(("implausible_forecast", 8, f"Go-live forecast in {dtf} days but only {p['pct_complete']}% complete"))
    if p["status"] == "Blocked":
        s.append(("blocked", 15, "Status is Blocked"))
    deps_on_me = [d for d in dependents.get(p["id"], []) if d["status"] != "Done"]
    if deps_on_me:
        s.append(("downstream_impact", min(12, 4 * len(deps_on_me)), "Blocks " + ", ".join(d["id"] for d in deps_on_me)))
    return s

def score_all(projects, people):
    byid = {p["id"]: p for p in projects}
    dependents = {}
    for p in projects:
        for d in p["dependencies"]:
            dependents.setdefault(d, []).append(p)
    res = {}
    for p in projects:  # pass 1
        sig = base_signals(p, people, dependents)
        raw = sum(x[1] for x in sig)
        res[p["id"]] = {"signals": sig, "raw": raw}
    for p in projects:  # pass 2: upstream + mismatch
        if p["status"] == "Done":
            res[p["id"]].update(score=0, computed_rag="Green", flags=[]); continue
        sig = res[p["id"]]["signals"]
        up = [d for d in p["dependencies"] if byid[d]["status"] != "Done" and min(100, res[d]["raw"] * W[byid[d]["priority"]]) >= 60]
        if up:
            sig.append(("upstream_risk", 10, "Depends on at-risk " + ", ".join(up)))
        raw = sum(x[1] for x in sig)
        flags = []
        if p["reported_rag"] == "Green" and raw >= 40:
            sig.append(("status_mismatch", 10, f"Reported GREEN but data signals score {raw:.0f}"))
            flags.append("WATERMELON")
            raw += 10
        score = round(min(100, raw * W[p["priority"]]), 1)
        if p["reported_rag"] == "Red" and score < 20:
            flags.append("REPORTED_RED_DATA_OK")
        crag = "Red" if score >= 60 else "Amber" if score >= 35 else "Green"
        res[p["id"]].update(score=score, computed_rag=crag, flags=flags)
    return res

def ranking(projects, people):
    r = score_all(projects, people)
    pr = {"P0": 0, "P1": 1, "P2": 2}
    live = [p for p in projects if p["status"] != "Done"]
    live.sort(key=lambda p: (-r[p["id"]]["score"], pr[p["priority"]], -(D(p["forecast_due"]) - D(p["baseline_due"])).days))
    return [(p["id"], r[p["id"]]) for p in live], r

if __name__ == "__main__":
    projects = build_projects()
    people = {p[0]: {"id": p[0], "name": p[1], "title": p[2], "function_code": p[3], "active": p[4]} for p in PEOPLE}
    rk, _ = ranking(projects, people)
    for pid, x in rk[:12]:
        print(pid, x["score"], x["computed_rag"], x["flags"], [s[0] for s in x["signals"]])
