import json, csv, copy, datetime as dt, os
import generate as g
from generate import D

OUT = g.OUT
LAST = {"RE": "2026-11-12", "SC": "2026-11-13", "TP": "2026-11-13", "MB": "2026-11-13",
        "CX": "2026-11-13", "IN": "2026-11-11", "FS": "2026-11-10", "PC": "2026-11-11"}
SRC = {"RE": "01_retail_expansion_email.txt", "SC": "02_supply_chain_tracker.csv", "TP": "03_technology_jira_export.json",
       "MB": "04_marketing_slack_thread.txt", "CX": "05_cx_rag_update.md", "IN": "06_international_slides.txt",
       "FS": "07_finance_memo.txt", "PC": "08_people_voice_note.txt"}
STALE = {"TP-01", "IN-02"}
NOTE = {
 "RE-01": "68/120 live; 9 opened this week. 11 Dec stores have only 1 optometrist rostered. Lab TAT may stay at 96h.",
 "RE-02": "152/200 done; 150-by-Oct milestone missed by 6 days (Pune fixture vendor). Forecast 15 Jan.",
 "RE-03": "38/60 partners signed. Partners asking about GST e-invoicing (FS-04).",
 "RE-04": "Closed: 15/15 kiosks live. Scale decision at Q4 review.",
 "RE-05": "Not started; kicks off 1 Dec after FS-02 sign-off.",
 "SC-01": "30% volume milestone hit 4 Nov (4 days late). Two Rajkot vendors failing acetate QC.",
 "SC-02": "Coating line arrived 3 Nov after a 19-day customs hold. Commissioning (due 10 Nov) not done; OEM engineer arrives 18 Nov. Full capacity ~10 Jan. INR 74 of 85 cr spent.",
 "SC-03": "Racking 70% installed; WMS go-live on track for 15 Dec.",
 "SC-04": "64/120 SKUs live; one-week slip on toric brand approvals.",
 "SC-05": "Closed: refurb cell live 10 Nov.",
 "TP-01": "On track for 20 Nov go-live.",
 "TP-02": "Accuracy 93.4% vs 95% target; beta to 50k users on 10 Dec.",
 "TP-03": "Face-mesh model 6 days late; due date moved to 24 Dec.",
 "TP-04": "2,080/2,600 stores migrated; no P1 incidents in 14 days.",
 "TP-05": "Blocked on CDP vendor contract (FS-03). Team redeployed to POS.",
 "MB-01": "Creative approved; media plan locks 20 Nov. 3x volume plan assumes new checkout + Bhiwadi capacity.",
 "MB-02": "262 creators onboarded; 250 milestone hit 12 Nov.",
 "MB-03": "Owner reports RED (nervous about new agency) but script/director locked 1 day early; shoot and release dates unchanged.",
 "MB-04": "Bengali + Gujarati live next week; CAC 395 vs 410 target.",
 "MB-05": "Closed.",
 "CX-01": "29 cities live. Fleet partner renewal (due 1 Nov) still in negotiation; partner wants a 22% rate rise.",
 "CX-02": "86% hit rate. Expansion past 240 cities paused until Bhiwadi Ph-2 capacity.",
 "CX-03": "NPS 64 vs 72. Queue-app pilot missed 31 Oct (POS integration bug). Weekend waits 38 min.",
 "CX-04": "Journey designed; build depends on UPI Autopay (TP-01).",
 "CX-05": "31% deflection; returns self-serve in UAT.",
 "IN-01": "3 stores live; Balady licences 3/8, 31 Oct milestone missed. Revised to 30 Apr.",
 "IN-02": "WMS integration in progress.",
 "IN-03": "24/24 styles approved; samples due 20 Dec.",
 "IN-04": "App localised; 8 stores move to unified inventory by 30 Nov.",
 "IN-05": "Not started; awaiting Board in Jan.",
 "FS-01": "Closed: results approved 5 Nov; analyst day held 6 Nov.",
 "FS-02": "5/6 cohorts modelled; CFO review 30 Nov.",
 "FS-03": "Contract (due 31 Oct) not signed; data-residency clauses. Legal expects 15 Dec. Gates TP-05.",
 "FS-04": "45% of partners live; ERP testing ends 15 Nov.",
 "FS-05": "INR 22 cr locked; INR 20 cr milestone hit 10 days late. 14 mall rent renegotiations pending.",
 "PC-01": "212/450. Run-rate ~22/week vs ~40 needed. 300-by-Oct missed; batch 3 not complete (2 trainers left). Forecast 31 Jan. Stipend decision needed.",
 "PC-02": "Cohort 1 (120) graduated.",
 "PC-03": "Closed.",
 "PC-04": "Still blocked on landlord NOC. Low priority.",
 "PC-05": "Attrition 41% vs 35% target. New incentive plan live since Sep.",
}

def main():
    for k in g.P:
        if k["code"] not in STALE:
            k["last"] = LAST[k["code"][:2]]
    for (pid, n) in NOTE.items():
        g.NOTES[(pid, "2026-11-09")] = n
    projects = g.build_projects()
    for p in projects:
        for h in p["weekly_history"]:
            if h["week_of"] == "2026-11-09":
                h["source"] = "weekly_updates/" + SRC[p["function_code"]]
            elif not h["note"]:
                h["note"] = f"Progress at {h['pct_complete']}%."
        if p["id"] == "TP-01":
            p["weekly_history"][-1]["note"] = "On track for 20 Nov go-live. UAT in progress."
        if p["id"] == "IN-02":
            p["weekly_history"][-1]["note"] = "WMS integration in progress. (Last update before owner Faisal Qureshi left on 20 Oct.)"
    people = [{"id": a, "name": b, "title": c, "function_code": d, "active": e,
               "email": b.lower().replace(" ", ".") + "@lenskart.example"} for a, b, c, d, e in g.PEOPLE]
    pmap = {p["id"]: p for p in people}
    functions = [{"code": c, "name": n, "update_format": f, "head_id": next(p["id"] for p in people if p["function_code"] == c and p["title"].startswith(("Head", "Chief"))),
                  "sample_update_file": "weekly_updates/" + SRC[c], "update_cadence": "Weekly, by Friday 6 PM IST"} for c, n, f in g.FUNCTIONS]

    meta = {"company": "Lenskart (fictional sample data - all people, numbers and events invented)",
            "as_of_date": "2026-11-14", "current_week_of": "2026-11-09", "currency": "INR crore",
            "weeks_of_history": g.WEEKS, "timezone": "Asia/Kolkata"}
    os.makedirs(OUT, exist_ok=True)
    dump = lambda name, obj: json.dump(obj, open(os.path.join(OUT, name), "w"), indent=2, ensure_ascii=False)
    dump("seed.json", {"meta": meta, "functions": functions, "people": people, "projects": projects})
    dump("people.json", people); dump("functions.json", functions); dump("projects.json", projects)

    # flat CSVs
    with open(os.path.join(OUT, "projects_flat.csv"), "w", newline="") as f:
        w = csv.writer(f); cols = ["id","name","function","priority","owner_name","exec_sponsor_name","status","reported_rag","start_date","baseline_due","forecast_due","pct_complete","budget_inr_cr","spent_inr_cr","confidence","last_update_date","dependencies"]
        w.writerow(cols)
        for p in projects: w.writerow([";".join(p[c]) if c == "dependencies" else p[c] for c in cols])
    with open(os.path.join(OUT, "milestones_flat.csv"), "w", newline="") as f:
        w = csv.writer(f); w.writerow(["project_id","milestone","due","done_date","status"])
        for p in projects:
            for m in p["milestones"]: w.writerow([p["id"], m["name"], m["due"], m["done_date"] or "", m["status"]])
    with open(os.path.join(OUT, "weekly_history_flat.csv"), "w", newline="") as f:
        w = csv.writer(f); w.writerow(["project_id","week_of","reported_rag","reported_status","pct_complete","forecast_due","confidence","note","source"])
        for p in projects:
            for h in p["weekly_history"]: w.writerow([p["id"], h["week_of"], h["reported_rag"], h["reported_status"], h["pct_complete"], h["forecast_due"], h["confidence"], h["note"], h["source"]])

    # expected extractions (ground truth for parser tests)
    ex = {}
    for c, src in SRC.items():
        items = []
        for p in projects:
            if p["function_code"] != c or p["id"] in STALE: continue
            items.append({"project_id": p["id"], "reported_status": p["status"], "reported_rag": p["reported_rag"],
                          "pct_complete": p["pct_complete"], "forecast_due": p["forecast_due"], "confidence": p["confidence"],
                          "note": NOTE[p["id"]]})
        ex[src] = {"function_code": c, "format": next(f for cc, n, f in g.FUNCTIONS if cc == c),
                   "update_date": LAST[c], "items": items,
                   "projects_not_mentioned": [p["id"] for p in projects if p["function_code"] == c and p["id"] in STALE]}
    for src in ex:  # handle fields the source genuinely doesn't contain
        if ex[src]["function_code"] == "IN":
            for it in ex[src]["items"]:
                it["_tolerance"] = "Slides give month-level ETAs (e.g. 'Apr-27'). Parser may resolve to month-end."
        if ex[src]["function_code"] in ("RE", "PC", "MB"):
            for it in ex[src]["items"]:
                it.setdefault("_tolerance", "Prose/chat source: some fields may be absent. Keep the previous value when missing.")
    json.dump(ex, open(os.path.join(OUT, "weekly_updates", "expected_extractions.json"), "w"), indent=2, ensure_ascii=False)

    # ---- demo steps: apply cumulatively and record expected rankings ----
    def apply(projs, upd):
        p = next(x for x in projs if x["id"] == upd["project_id"])
        for f in ("status", "reported_rag", "pct_complete", "forecast_due", "confidence"):
            if f in upd: p[f] = upd[f]
        p["last_update_date"] = upd["update_date"]
        for mu in upd.get("milestone_updates", []):
            m = next(m for m in p["milestones"] if m["name"] == mu["name"])
            m["done_date"] = mu["done_date"]
        entry = {"week_of": "2026-11-09", "reported_rag": p["reported_rag"], "reported_status": p["status"],
                 "pct_complete": p["pct_complete"], "forecast_due": p["forecast_due"], "confidence": p["confidence"],
                 "note": upd["note"], "source": upd["source"]}
        p["weekly_history"] = [h for h in p["weekly_history"] if h["week_of"] != "2026-11-09"] + [entry]

    steps = [
      {"step": "A", "trigger": "Paste into Ingest page (manual input -> agent parse)", "file": "demo_inputs/A_cx_escalation_email.txt",
       "update": {"project_id": "CX-01", "status": "Blocked", "reported_rag": "Red", "pct_complete": 48, "forecast_due": "2027-03-31", "confidence": 1,
                  "update_date": "2026-11-14", "note": "Fleet partner served termination notice effective 30 Nov after renewal talks failed. 14 of 29 cities lose vans. Expansion paused.", "source": "demo_inputs/A_cx_escalation_email.txt"}},
      {"step": "B", "trigger": "Webhook POST /api/webhooks/update (curl)", "file": "demo_inputs/B_tp01_webhook_payload.json",
       "update": {"project_id": "TP-01", "status": "On Track", "reported_rag": "Green", "pct_complete": 78, "forecast_due": "2026-11-27", "confidence": 4,
                  "update_date": "2026-11-14", "milestone_updates": [{"name": "UAT sign-off", "done_date": "2026-11-13"}, {"name": "PCI-DSS security audit passed", "done_date": "2026-11-14"}],
                  "note": "UAT signed off 13 Nov, PCI audit passed 14 Nov. Load test moved to 18 Nov. Go-live moved 7 days to 27 Nov. Still ahead of the 15 Dec sale.", "source": "demo_inputs/B_tp01_webhook_payload.json"}},
      {"step": "C", "trigger": "Drop file into ./inbox/ (folder watcher picks it up)", "file": "demo_inputs/C_supply_chain_inbox_drop.csv",
       "update": {"project_id": "SC-02", "status": "At Risk", "reported_rag": "Amber", "pct_complete": 68, "forecast_due": "2026-12-28", "confidence": 3,
                  "update_date": "2026-11-14", "note": "Third shift approved on existing line for Dec peak. OEM engineer pulled forward to 16 Nov. Full capacity now 28 Dec.", "source": "demo_inputs/C_supply_chain_inbox_drop.csv"}},
    ]
    people_idx = {p["id"]: p for p in people}
    results = {}
    cur = copy.deepcopy(projects)
    def snap(label):
        rk, _ = g.ranking(cur, people_idx)
        results[label] = {"top3": [pid for pid, _ in rk[:3]],
                          "ranking": [{"rank": i + 1, "project_id": pid, "score": x["score"], "computed_rag": x["computed_rag"], "flags": x["flags"],
                                       "signals": [{"key": s[0], "points": round(s[1], 2), "why": s[2]} for s in x["signals"]]} for i, (pid, x) in enumerate(rk)]}
    snap("baseline")
    for s in steps:
        apply(cur, s["update"]); snap("after_" + s["step"])
    json.dump({"as_of_date": "2026-11-14", "formula": "see PROMPT.md section 6", "tolerance": "+/- 1.0 point",
               "demo_steps": [{k: v for k, v in s.items()} for s in steps], "expected": results},
              open(os.path.join(OUT, "expected_scores.json"), "w"), indent=2, ensure_ascii=False)
    for lbl, r in results.items():
        print(lbl, [(x["project_id"], x["score"]) for x in r["ranking"][:5]])

if __name__ == "__main__":
    main()
